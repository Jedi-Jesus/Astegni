# Authentication Systems - Visual Guide

## The Two Separate Worlds of Astegni Authentication

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         ASTEGNI PLATFORM                                 │
│                                                                           │
│  ┌────────────────────────────┐     ┌────────────────────────────┐     │
│  │   USER AUTHENTICATION      │     │   ADMIN AUTHENTICATION     │     │
│  │   (Students/Tutors/Parents)│     │   (Admin Dashboard)         │     │
│  └────────────────────────────┘     └────────────────────────────┘     │
│           ↓                                    ↓                          │
│  ┌────────────────────────────┐     ┌────────────────────────────┐     │
│  │ DATABASE: users            │     │ DATABASE: admin_profile     │     │
│  │ ─────────────────────────  │     │ ─────────────────────────   │     │
│  │ id: 123                    │     │ id: 1                       │     │
│  │ email: john@example.com    │     │ email: john@example.com     │     │
│  │ roles: ["student","tutor"] │     │ departments: ["manage-..."] │     │
│  │ password_hash: $2b$...     │     │ password_hash: $2b$...      │     │
│  └────────────────────────────┘     └────────────────────────────┘     │
│           ↓                                    ↓                          │
│  ┌────────────────────────────┐     ┌────────────────────────────┐     │
│  │ LOGIN: /api/login          │     │ LOGIN: /api/admin/login     │     │
│  │ Method: POST               │     │ Method: POST                │     │
│  │ Body: username, password   │     │ Body: email, password       │     │
│  └────────────────────────────┘     └────────────────────────────┘     │
│           ↓                                    ↓                          │
│  ┌────────────────────────────┐     ┌────────────────────────────┐     │
│  │ TOKEN RESPONSE             │     │ TOKEN RESPONSE              │     │
│  │ ─────────────────────────  │     │ ─────────────────────────   │     │
│  │ {                          │     │ {                           │     │
│  │   access_token: "eyJ...",  │     │   access_token: "eyJ...",   │     │
│  │   user: {                  │     │   admin_id: 1,              │     │
│  │     id: 123,               │     │   email: "john@...",        │     │
│  │     roles: ["student"],    │     │   departments: ["..."],     │     │
│  │     active_role: "student" │     │   type: "admin"             │     │
│  │   }                        │     │ }                           │     │
│  │ }                          │     │                             │     │
│  └────────────────────────────┘     └────────────────────────────┘     │
│           ↓                                    ↓                          │
│  ┌────────────────────────────┐     ┌────────────────────────────┐     │
│  │ LOCALSTORAGE               │     │ LOCALSTORAGE                │     │
│  │ ─────────────────────────  │     │ ─────────────────────────   │     │
│  │ token: "eyJ..."            │     │ adminSession: "eyJ..."      │     │
│  │ currentUser: "{...}"       │     │ adminProfile: "{...}"       │     │
│  │ refreshToken: "eyJ..."     │     │ adminId: 1                  │     │
│  └────────────────────────────┘     └────────────────────────────┘     │
│           ↓                                    ↓                          │
│  ┌────────────────────────────┐     ┌────────────────────────────┐     │
│  │ PAGES                      │     │ PAGES                       │     │
│  │ ─────────────────────────  │     │ ─────────────────────────   │     │
│  │ profile-pages/             │     │ admin-pages/                │     │
│  │   - student-profile.html   │     │   - admin-index.html        │     │
│  │   - tutor-profile.html     │     │   - manage-courses.html     │     │
│  │   - parent-profile.html    │     │   - manage-tutors.html      │     │
│  └────────────────────────────┘     └────────────────────────────┘     │
│           ↓                                    ↓                          │
│  ┌────────────────────────────┐     ┌────────────────────────────┐     │
│  │ AUTH MANAGER               │     │ AUTH MANAGER                │     │
│  │ ─────────────────────────  │     │ ─────────────────────────   │     │
│  │ js/root/auth.js            │     │ js/admin-pages/admin-...    │     │
│  │ AuthenticationManager      │     │ Admin login handlers        │     │
│  │ - isAuthenticated()        │     │ - checkAccess()             │     │
│  │ - getUserRole()            │     │ - getDepartments()          │     │
│  └────────────────────────────┘     └────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────────┘
```

## Your Current Situation

```
YOU:
┌──────────────────────────────────────────────────────────┐
│ Email: your-email@example.com                             │
│                                                           │
│ ┌─────────────────────┐    ┌────────────────────────┐   │
│ │ USER ACCOUNT        │    │ ADMIN ACCOUNT          │   │
│ ├─────────────────────┤    ├────────────────────────┤   │
│ │ Table: users        │    │ Table: admin_profile   │   │
│ │ ID: 123             │    │ ID: 1                  │   │
│ │ Role: student       │    │ Dept: manage-courses   │   │
│ │ Password: ****      │    │ Password: ****         │   │
│ └─────────────────────┘    └────────────────────────┘   │
│         ↓                            ↓                    │
│ Two SEPARATE accounts with SAME email                    │
└──────────────────────────────────────────────────────────┘
```

## What Was Happening (BEFORE THE FIX)

```
PROBLEM FLOW:
┌─────────────────────────────────────────────────────────────┐
│ 1. You login as USER from index.html                         │
│    ↓                                                         │
│    POST /api/login → queries users table                    │
│    ↓                                                         │
│    localStorage.token = "user_token_here"                   │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. You navigate to student-profile.html                      │
│    ↓                                                         │
│    Page loads BOTH:                                          │
│    - js/root/auth.js (user auth) ✅                          │
│    - js/admin-pages/shared/sidebar-fix.js (admin code) ❌   │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. Student-profile.html checks authentication                │
│    ↓                                                         │
│    init.js checks: AuthManager.isAuthenticated()            │
│    → Finds localStorage.token → Works! ✅                   │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ 4. You RELOAD the page                                       │
│    ↓                                                         │
│    BOTH tokens exist in localStorage:                        │
│    - localStorage.token (user) ✅                            │
│    - localStorage.adminSession (from previous admin login) ❌│
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ 5. Admin script runs and checks adminSession ❌              │
│    ↓                                                         │
│    Finds localStorage.adminSession → Shows "admin" message  │
│    ↓                                                         │
│    CONFUSION! Page shows "logged in as admin"               │
└─────────────────────────────────────────────────────────────┘
```

## What Happens Now (AFTER THE FIX)

```
FIXED FLOW:
┌─────────────────────────────────────────────────────────────┐
│ 1. You login as USER from index.html                         │
│    ↓                                                         │
│    POST /api/login → queries users table                    │
│    ↓                                                         │
│    localStorage.token = "user_token_here"                   │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. You navigate to student-profile.html                      │
│    ↓                                                         │
│    Page loads ONLY:                                          │
│    - js/root/auth.js (user auth) ✅                          │
│    - NO ADMIN SCRIPTS! ✅                                    │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. Student-profile.html checks authentication                │
│    ↓                                                         │
│    init.js checks: AuthManager.isAuthenticated()            │
│    → Finds localStorage.token → Works! ✅                   │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ 4. You RELOAD the page                                       │
│    ↓                                                         │
│    Only user auth is checked (no admin scripts)              │
│    → Finds localStorage.token → Works! ✅                   │
│    ↓                                                         │
│    SUCCESS! No confusion.                                    │
└─────────────────────────────────────────────────────────────┘
```

## The Fix in Simple Terms

### BEFORE (Wrong):
```html
<!-- student-profile.html -->
<script src="../js/root/auth.js"></script>  <!-- USER auth -->
<script src="../js/admin-pages/shared/sidebar-fix.js"></script>  <!-- ADMIN auth ❌ -->
```

### AFTER (Correct):
```html
<!-- student-profile.html -->
<script src="../js/root/auth.js"></script>  <!-- USER auth only ✅ -->
<!-- NO admin scripts! -->
```

## Rule of Thumb

```
┌──────────────────────────────────────────────────────────┐
│ GOLDEN RULE:                                              │
│                                                           │
│ User pages (profile-pages/*) = ONLY user auth scripts    │
│ Admin pages (admin-pages/*) = ONLY admin auth scripts    │
│                                                           │
│ NEVER MIX THEM!                                           │
└──────────────────────────────────────────────────────────┘
```

## How to Switch Between User and Admin

```
SCENARIO: You want to switch from student mode to admin mode

┌─────────────────────────────────────────────────────────────┐
│ Step 1: Clear localStorage                                   │
│ ─────────────────────────────────────────────────────────── │
│ Open browser console (F12)                                   │
│ Run: localStorage.clear();                                   │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ Step 2: Choose your destination                              │
│ ─────────────────────────────────────────────────────────── │
│ FOR USER MODE:                                               │
│   → Go to index.html                                         │
│   → Login with user credentials                              │
│   → Access profile-pages/student-profile.html               │
│                                                              │
│ FOR ADMIN MODE:                                              │
│   → Go to admin-pages/admin-index.html                      │
│   → Login with admin credentials                             │
│   → Access admin-pages/*.html                               │
└─────────────────────────────────────────────────────────────┘
```

## localStorage Contents - What Should You See?

### When Logged in as USER (Student):
```javascript
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "currentUser": "{\"id\":123,\"email\":\"john@example.com\",\"roles\":[\"student\"]}",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "adminSession": null,  // Should be empty!
  "adminProfile": null   // Should be empty!
}
```

### When Logged in as ADMIN:
```javascript
{
  "adminSession": "{\"access_token\":\"eyJ...\",\"admin_id\":1}",
  "adminProfile": "{\"id\":1,\"email\":\"john@example.com\",\"departments\":[...]}",
  "adminId": "1",
  "token": null,         // Should be empty!
  "currentUser": null    // Should be empty!
}
```

## Summary - The Two Authentication Universes

```
┌────────────────────────────────────────────────────────────────┐
│                     UNIVERSE 1: USERS                           │
├────────────────────────────────────────────────────────────────┤
│ Purpose:        Students, Tutors, Parents learn and teach       │
│ Login Page:     index.html                                      │
│ Endpoint:       POST /api/login                                 │
│ Table:          users                                           │
│ Token Key:      localStorage.token                              │
│ Auth File:      js/root/auth.js                                 │
│ Pages:          profile-pages/*.html                            │
└────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│                     UNIVERSE 2: ADMINS                          │
├────────────────────────────────────────────────────────────────┤
│ Purpose:        Admins manage the platform                      │
│ Login Page:     admin-pages/admin-index.html                   │
│ Endpoint:       POST /api/admin/login                           │
│ Table:          admin_profile                                   │
│ Token Key:      localStorage.adminSession                       │
│ Auth File:      js/admin-pages/admin-index.js                  │
│ Pages:          admin-pages/*.html                              │
└────────────────────────────────────────────────────────────────┘

                NEVER SHALL THE TWO MEET! 🚫
```

## Next Steps

1. ✅ **Fix Applied:** Admin scripts removed from student-profile.html
2. 🧪 **Test It:** Clear localStorage and login fresh
3. 📚 **Understand:** Users and Admins are separate systems
4. 🎯 **Remember:** Same email = Two different accounts (users vs admin_profile)
5. 🔄 **Switching:** Always clear localStorage when switching modes
