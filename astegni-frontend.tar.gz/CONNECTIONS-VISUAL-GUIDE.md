# Visual Guide: Connections System

## Before vs After

### Old System (tutor_connections)

```
┌─────────────────────────────────────────────────────────────┐
│                    tutor_connections                        │
├─────────────────────────────────────────────────────────────┤
│  • Only students can connect with tutors                   │
│  • student_id → users.id                                   │
│  • tutor_id → tutor_profiles.id                            │
│  • Limited to one relationship type                        │
│                                                             │
│  Student 98 ───────► Tutor Profile 53                      │
│  (student_id=98)     (tutor_id=53)                         │
└─────────────────────────────────────────────────────────────┘
```

### New System (connections)

```
┌─────────────────────────────────────────────────────────────┐
│                       connections                           │
├─────────────────────────────────────────────────────────────┤
│  • Anyone can connect with anyone                          │
│  • user_id_1 → users.id                                    │
│  • user_id_2 → users.id                                    │
│  • Multiple connection types: follow, friend, block        │
│                                                             │
│  User 98 ───follow──► User 75 (Tutor)                     │
│  User 98 ───friend──► User 99 (Student)                   │
│  User 98 ───block───► User 100                            │
└─────────────────────────────────────────────────────────────┘
```

---

## Connection Types

### 1. Follow (Directional)

```
┌──────────┐                    ┌──────────┐
│ Student  │                    │  Tutor   │
│  (98)    │ ──────follow─────► │  (75)    │
└──────────┘                    └──────────┘

Behavior:
• Student follows Tutor (one-way)
• Tutor doesn't automatically follow back
• Status: 'accepted' (immediate)
• Like Instagram/Twitter

Database:
user_id_1: 98 (follower)
user_id_2: 75 (following)
connection_type: 'follow'
status: 'accepted'
```

### 2. Friend (Bidirectional)

```
Step 1: Request
┌──────────┐                    ┌──────────┐
│ Student  │                    │ Student  │
│   (98)   │ ─────request────► │   (99)   │
└──────────┘                    └──────────┘
              status: 'pending'

Step 2: Accept
┌──────────┐                    ┌──────────┐
│ Student  │                    │ Student  │
│   (98)   │ ◄────friends────► │   (99)   │
└──────────┘                    └──────────┘
              status: 'accepted'

Behavior:
• Requires acceptance
• Creates mutual relationship
• Status: 'pending' → 'accepted'
• Like Facebook friends

Database:
user_id_1: 98 (requester)
user_id_2: 99 (recipient)
connection_type: 'friend'
status: 'pending' → 'accepted'
```

### 3. Block

```
┌──────────┐                    ┌──────────┐
│ Student  │                    │ Blocked  │
│  (98)    │ ──────block──────X │  User    │
└──────────┘                    └──────────┘

Behavior:
• Prevents interaction
• Status: 'accepted' (immediate)
• One-way blocking

Database:
user_id_1: 98 (blocker)
user_id_2: 100 (blocked)
connection_type: 'block'
status: 'accepted'
```

---

## API Flow Examples

### Example 1: Student Follows Tutor

```
┌─────────────────────────────────────────────────────────────┐
│ 1. Student clicks "Follow" on Tutor's profile              │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. Frontend: POST /api/connections                          │
│    {                                                        │
│      "target_user_id": 75,                                  │
│      "connection_type": "follow"                            │
│    }                                                        │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. Backend creates connection:                              │
│    - user_id_1: 98 (student)                                │
│    - user_id_2: 75 (tutor)                                  │
│    - status: 'accepted' (immediate for follow)              │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. Response: 201 Created                                    │
│    {                                                        │
│      "id": 1,                                               │
│      "status": "accepted",                                  │
│      "connection_type": "follow"                            │
│    }                                                        │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. Frontend updates UI:                                     │
│    - Button: "Follow" → "Following"                         │
│    - Update follower count                                  │
└─────────────────────────────────────────────────────────────┘
```

### Example 2: Student Sends Friend Request

```
┌─────────────────────────────────────────────────────────────┐
│ 1. Student A clicks "Add Friend" on Student B's profile    │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. Frontend: POST /api/connections                          │
│    {                                                        │
│      "target_user_id": 99,                                  │
│      "connection_type": "friend",                           │
│      "connection_message": "Let's be friends!"              │
│    }                                                        │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. Backend creates connection:                              │
│    - status: 'pending' (requires acceptance)                │
│    - Student B receives notification                        │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. Student B views request and clicks "Accept"             │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. Frontend: PUT /api/connections/{id}                      │
│    {                                                        │
│      "status": "accepted"                                   │
│    }                                                        │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 6. Both students are now friends!                           │
│    - Connection status: 'accepted'                          │
│    - Both see each other in friends list                    │
└─────────────────────────────────────────────────────────────┘
```

---

## Database Relationships

```
┌──────────────────┐
│      users       │
│                  │
│  id  (PK)        │◄─────┐
│  email           │      │
│  first_name      │      │
│  ...             │      │
└──────────────────┘      │
                          │
                          │ Foreign Key
                          │
┌────────────────────────────────────────────┐
│            connections                     │
│                                            │
│  id  (PK)                                  │
│  user_id_1  (FK → users.id) ──────────────┘
│  user_id_2  (FK → users.id) ──────────────┐
│  connection_type  (follow/friend/block)   │
│  status  (pending/accepted/rejected)      │
│  initiated_by  (FK → users.id)            │
│  connection_message  (TEXT)               │
│  created_at  (TIMESTAMP)                  │
│  accepted_at  (TIMESTAMP)                 │
│  updated_at  (TIMESTAMP)                  │
│                                            │
│  UNIQUE (user_id_1, user_id_2, type)      │
│  CHECK (user_id_1 != user_id_2)           │
└────────────────────────────────────────────┘
                          │
                          │ Foreign Key
                          │
                          ▼
┌──────────────────┐
│      users       │
│                  │
│  id  (PK)        │
│  email           │
│  first_name      │
│  ...             │
└──────────────────┘
```

---

## Query Patterns

### Get My Followers

```sql
SELECT u.*, c.*
FROM connections c
JOIN users u ON c.user_id_1 = u.id
WHERE c.user_id_2 = :my_user_id
  AND c.connection_type = 'follow'
  AND c.status = 'accepted'

Result:
┌──────────────────────────────────┐
│  Users who follow ME             │
│  (I am user_id_2 in these rows)  │
└──────────────────────────────────┘
```

### Get Who I'm Following

```sql
SELECT u.*, c.*
FROM connections c
JOIN users u ON c.user_id_2 = u.id
WHERE c.user_id_1 = :my_user_id
  AND c.connection_type = 'follow'
  AND c.status = 'accepted'

Result:
┌──────────────────────────────────┐
│  Users I follow                  │
│  (I am user_id_1 in these rows)  │
└──────────────────────────────────┘
```

### Get My Friends

```sql
SELECT u.*, c.*
FROM connections c
JOIN users u ON (
  CASE
    WHEN c.user_id_1 = :my_user_id THEN u.id = c.user_id_2
    WHEN c.user_id_2 = :my_user_id THEN u.id = c.user_id_1
  END
)
WHERE (c.user_id_1 = :my_user_id OR c.user_id_2 = :my_user_id)
  AND c.connection_type = 'friend'
  AND c.status = 'accepted'

Result:
┌──────────────────────────────────┐
│  My friends (bidirectional)      │
│  (I can be either user_id)       │
└──────────────────────────────────┘
```

---

## Statistics Dashboard

```
┌─────────────────────────────────────────────────────────────┐
│                    User Profile Stats                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Followers:  150  (users following me)                      │
│  Following:   80  (users I follow)                          │
│  Friends:     45  (mutual connections)                      │
│                                                             │
│  Pending Requests:                                          │
│    Received:  10  (requests I need to accept/reject)        │
│    Sent:       5  (requests awaiting response)              │
│                                                             │
│  Blocked:      2  (users I've blocked)                      │
│                                                             │
│  Total Connections: 275                                     │
└─────────────────────────────────────────────────────────────┘

API Endpoint: GET /api/connections/stats

Response:
{
  "followers_count": 150,
  "following_count": 80,
  "friends_count": 45,
  "pending_received_count": 10,
  "pending_sent_count": 5,
  "blocked_count": 2,
  "total_connections": 275
}
```

---

## Frontend UI Components

### Profile Page - Follow Button

```
┌────────────────────────────────────────────┐
│  Tutor Profile                             │
│  ──────────────                            │
│                                            │
│  Name: Dr. Abebe Bekele                   │
│  Subject: Mathematics                      │
│                                            │
│  [Following ▼]  [Message]  [Share]         │
│                                            │
│  150 Followers  |  80 Following            │
└────────────────────────────────────────────┘

Button States:
• Not connected:  [+ Follow]
• Pending:        [Request Sent]
• Connected:      [Following ▼]
  Dropdown:       - Unfollow
                  - Block User
```

### Connections List

```
┌────────────────────────────────────────────┐
│  My Connections                            │
│  ──────────────                            │
│                                            │
│  Tabs: [Followers] [Following] [Friends]   │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │ 👤 Sarah Tesfaye                     │ │
│  │    Student • 2 mutual connections     │ │
│  │    [Message] [Unfollow]               │ │
│  └──────────────────────────────────────┘ │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │ 👤 Dr. Hailu Mekuria                 │ │
│  │    Tutor • Mathematics                │ │
│  │    [Message] [Unfollow]               │ │
│  └──────────────────────────────────────┘ │
│                                            │
└────────────────────────────────────────────┘
```

### Pending Requests

```
┌────────────────────────────────────────────┐
│  Friend Requests (10)                      │
│  ────────────────────                      │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │ 👤 Ahmed Ibrahim                     │ │
│  │    "Let's study together!"            │ │
│  │    Student • Grade 11                 │ │
│  │    [Accept] [Reject]                  │ │
│  └──────────────────────────────────────┘ │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │ 👤 Hana Alemu                        │ │
│  │    "Hi! Nice to meet you"             │ │
│  │    Student • Grade 12                 │ │
│  │    [Accept] [Reject]                  │ │
│  └──────────────────────────────────────┘ │
│                                            │
└────────────────────────────────────────────┘
```

---

## Migration Flow

```
┌─────────────────────────────────────────────────────────────┐
│  STEP 1: Old Data (tutor_connections)                      │
├─────────────────────────────────────────────────────────────┤
│  ID  student_id  tutor_id  status                          │
│  2   98          53        pending                         │
│  13  98          51        pending                         │
└─────────────────────────────────────────────────────────────┘
                          │
                          │ Migration Script
                          ▼
┌─────────────────────────────────────────────────────────────┐
│  STEP 2: Transform                                          │
├─────────────────────────────────────────────────────────────┤
│  • Lookup tutor_id 53 → user_id 75                         │
│  • Lookup tutor_id 51 → user_id 73                         │
│  • Convert to "follow" connection type                      │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│  STEP 3: New Data (connections)                            │
├─────────────────────────────────────────────────────────────┤
│  ID  user_id_1  user_id_2  type    status                  │
│  1   98         75         follow  pending                 │
│  2   98         73         follow  pending                 │
└─────────────────────────────────────────────────────────────┘
```

---

## Use Cases

### 1. Student Following Tutors

```
Student (98) ───follow──► Tutor A (75)
             ───follow──► Tutor B (73)
             ───follow──► Tutor C (80)

Benefits:
• See tutor updates in feed
• Get notifications
• Quick access to profiles
• No approval needed
```

### 2. Students Connecting as Friends

```
Student A (98) ───request──► Student B (99)
               ◄──accept───

Benefits:
• Study together
• Share notes
• Group projects
• Mutual support
```

### 3. Tutors Networking

```
Tutor A (75) ───request──► Tutor B (73)
             ◄──accept───

Benefits:
• Professional networking
• Share resources
• Collaborate on courses
• Refer students
```

### 4. Parent-Student Monitoring

```
Parent (101) ───follow──► Student (98)

Benefits:
• Monitor progress
• See activities
• Track connections
• Support learning
```

---

## Summary

### Key Concepts

1. **Universal**: Any user can connect with any user
2. **Flexible**: Three connection types (follow, friend, block)
3. **Directional**: Follow is one-way, Friend is two-way
4. **Status-aware**: Pending, Accepted, Rejected, Blocked
5. **Performant**: 7 indexes for fast queries

### Migration Success

- ✅ Old data preserved
- ✅ New functionality added
- ✅ Backward compatible
- ✅ Well documented
- ✅ Production ready

---

**Ready to use!** 🚀

See `CONNECTIONS-MIGRATION-COMPLETE.md` for complete details.
