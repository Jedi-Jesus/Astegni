"""
Add password_hash column to admin_profile table

This migration adds a password_hash field to the admin_profile table
to allow admins to have their own passwords separate from the main users table.
"""
import psycopg
from dotenv import load_dotenv
import os
from datetime import datetime
import sys
import io

# Force UTF-8 output encoding for Windows
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Load environment variables
load_dotenv()
DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://astegni_user:Astegni2025@localhost:5432/astegni_db')

def add_password_hash_column():
    """Add password_hash column to admin_profile table"""
    try:
        with psycopg.connect(DATABASE_URL) as conn:
            with conn.cursor() as cur:
                print("="*80)
                print("ADDING PASSWORD_HASH TO ADMIN_PROFILE TABLE")
                print("="*80)
                print()

                # Step 1: Check if admin_profile table exists
                print("Step 1: Checking if admin_profile table exists...")
                cur.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables
                        WHERE table_name = 'admin_profile'
                    )
                """)
                table_exists = cur.fetchone()[0]

                if not table_exists:
                    print("✗ admin_profile table does not exist!")
                    print("Please run migrate_admin_restructure.py first")
                    return

                print("✓ admin_profile table exists\n")

                # Step 2: Check if password_hash column already exists
                print("Step 2: Checking if password_hash column already exists...")
                cur.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.columns
                        WHERE table_name = 'admin_profile'
                        AND column_name = 'password_hash'
                    )
                """)
                column_exists = cur.fetchone()[0]

                if column_exists:
                    print("✓ password_hash column already exists in admin_profile table")
                    print("No migration needed\n")
                    return

                print("✓ password_hash column does not exist, proceeding with migration\n")

                # Step 3: Add password_hash column
                print("Step 3: Adding password_hash column...")
                cur.execute("""
                    ALTER TABLE admin_profile
                    ADD COLUMN password_hash VARCHAR(255)
                """)
                print("✓ password_hash column added successfully\n")

                # Step 4: Verify the column was added
                print("Step 4: Verifying column addition...")
                cur.execute("""
                    SELECT column_name, data_type, character_maximum_length
                    FROM information_schema.columns
                    WHERE table_name = 'admin_profile'
                    AND column_name = 'password_hash'
                """)
                result = cur.fetchone()

                if result:
                    print(f"✓ Column verified:")
                    print(f"   - Column name: {result[0]}")
                    print(f"   - Data type: {result[1]}")
                    print(f"   - Max length: {result[2]}\n")
                else:
                    print("✗ Could not verify column addition\n")

                # Commit all changes
                conn.commit()

                print("="*80)
                print("MIGRATION COMPLETED SUCCESSFULLY!")
                print("="*80)
                print("\nAdmin Profile Table Structure Updated:")
                print("   - Added: password_hash (VARCHAR 255)")
                print("\nNote: The password_hash field is now available for admin accounts.")
                print("It can store bcrypt hashed passwords separate from the main users table.")
                print("="*80)

    except Exception as e:
        print(f"✗ Error during migration: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    add_password_hash_column()
