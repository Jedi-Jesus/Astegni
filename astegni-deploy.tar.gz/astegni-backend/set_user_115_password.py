"""
Set a known password for user 115 (tutor) for testing
"""
import psycopg
import os
from dotenv import load_dotenv
import bcrypt

load_dotenv()
DATABASE_URL = os.getenv('DATABASE_URL')

# Hash the password
password = "TestPassword123"
password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

print(f"Setting password for user 115...")
print(f"New password: {password}")
print(f"Hash: {password_hash[:50]}...")

conn = psycopg.connect(DATABASE_URL)
cur = conn.cursor()

try:
    # Update user 115's password
    cur.execute("""
        UPDATE users
        SET password_hash = %s
        WHERE id = 115
        RETURNING id, email
    """, (password_hash,))

    result = cur.fetchone()

    if result:
        conn.commit()
        print(f"\n✅ Password updated for user {result[0]} ({result[1]})")
        print(f"\nYou can now login with:")
        print(f"  Email: {result[1]}")
        print(f"  Password: {password}")
    else:
        print("❌ User 115 not found!")

except Exception as e:
    conn.rollback()
    print(f"❌ Error: {e}")
finally:
    cur.close()
    conn.close()
