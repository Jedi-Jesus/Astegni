"""
Set password for test admin account
"""

import sys
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import psycopg
from dotenv import load_dotenv
import os
import bcrypt

load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL")

def set_test_admin_password():
    """Set password for test1@example.com"""

    conn = psycopg.connect(DATABASE_URL)
    cursor = conn.cursor()

    try:
        # Hash the password
        password = "password123"
        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

        # Update test admin password
        cursor.execute("""
            UPDATE admin_profile
            SET password_hash = %s
            WHERE email = 'test1@example.com'
        """, (password_hash,))

        conn.commit()

        # Check result (is_otp_verified removed - using password_hash presence instead)
        cursor.execute("""
            SELECT id, email, first_name, password_hash IS NOT NULL as has_password
            FROM admin_profile
            WHERE email = 'test1@example.com'
        """)

        result = cursor.fetchone()
        if result:
            admin_id, email, first_name, has_password = result
            print(f"✓ Password set for admin:")
            print(f"  ID: {admin_id}")
            print(f"  Email: {email}")
            print(f"  Name: {first_name}")
            print(f"  Verified: {has_password}")
            print(f"  Has Password: {has_password}")
            print(f"  Password: password123")
        else:
            print("✗ Admin not found")

    except Exception as e:
        print(f"Error: {e}")
        conn.rollback()
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    set_test_admin_password()
